import networkx as nx

def dominant(g):
    """
        :param g: the graph as a networkx structure (https://networkx.github.io/documentation/stable/reference/classes/graph.html)
    """
    return list(g.nodes), list(g.nodes)  # This solution is the worst possible, it returns all nodes in both dominants.